library(rgdal)
p<- readOGR(dsn = "R/EX_3", layer = "district" )
c=read.csv(file = "R/EX_3/Cropdetails.csv")
summary(p)
data.frame(p)
q <- merge(p, c, by.x='Name',by.y="District")#joining attribute table with csv file
data.frame(q)#displaying attribute table of a shapefile
plot(q)#plotting the shapefile in screen

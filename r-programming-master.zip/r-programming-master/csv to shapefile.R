library(rgdal)##including libraries
c=read.csv(file = "EX_3/Hospitals.csv")##read csv file
coordinates(c)<-cbind("Longitude","Latitude")##heading of the csv file
proj4string(c)<-CRS("+init=epsg:4326")
summary(c)
writeOGR(c, ".", "EX_3/hosp", driver="ESRI Shapefile")##Saving shape
plot(c)##for displaying file in the r


library(rgdal)
library(ggplot2)
library(ggmap)
p<-readOGR(dsn = ".", layer = "Trivandrum" )
plot(p)
p1<-readOGR(dsn = ".", layer = "Corp" )
plot(p1,add=TRUE)
bb<-bbox(p)
BBmap2<-get_map(location =bb,maptype = "terrain",source = "stamen",zoom = 10)
ggmap(BBmap2)+geom_polygon(data=p1,aes(x=long,y=lat),linetype=1,fill="yellow",color="red",alpha=0.5)

                           
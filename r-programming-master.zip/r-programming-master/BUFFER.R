library(rgdal)
library(rgeos)
p<- readOGR(dsn = ".", layer = "Assets1" )
q<- readOGR(dsn = ".", layer = "Roads1" )
newData<-spTransform(q,CRS("+init=epsg:32643"))##converting from one projection to another
buffer<-gBuffer( newData, width=2000, byid=TRUE)##creating buffer
plot(buffer)
plot(newData,add=TRUE)##APPENDING OLD DATA WITH BUFFERED DATA

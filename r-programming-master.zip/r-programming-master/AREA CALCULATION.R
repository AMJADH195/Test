library(rgdal)
library(rgeos)
p<- readOGR(dsn = ".", layer = "district" )
summary(p)
newData<-spTransform(p,CRS("+init=epsg:32643"))##converting from one projection to another
summary(newData)
gArea(newData,byid = TRUE)##FINDING AREA
newarea<-gArea(newData,byid = TRUE)##FINDING AREA and crea
data.frame(newarea)
newData$area<-newarea ##ASSIGNING A AREA TO A NEW FEILD IN ATTRIBUTE TABLE
summary(newData)

library(rgdal)
library(rgeos)
polygon1<-readOGR(dsn=".",layer='Field')
polygon1@data
polygon2<-readOGR(dsn=".",layer='Soil')
polygon2@data
plot(polygon1,col="REd")
plot(polygon2,add=TRUE)
union<-gUnion(polygon1,polygon2,byid = TRUE)
plot(union)
summary(union)
intersec<-gIntersection(polygon1,polygon2,byid = TRUE)
plot(intersec,col="RED",add=TRUE)
symmetricaldef<-gSymdifference(polygon1,polygon2)
summary(symmetricaldef)
plot(symmetricaldef,col="RED")

dif1<-gDifference(polygon1,polygon2,byid = FALSE)
plot(dif1,col="pink")

